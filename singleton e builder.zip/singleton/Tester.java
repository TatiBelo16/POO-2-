package singleton;

public class Tester {

	public static void main(String[] args) {
		
		
		
		
		/*
		Singleton s = Singleton.getInstancia();
		
		//Singleton y = new Singleton();
		
		System.out.println(s);
		
		Singleton x = Singleton.getInstancia();
		System.out.println(x);
		
		Singleton z = Singleton.getInstancia();
		System.out.println(z);
	*/
	}

}
