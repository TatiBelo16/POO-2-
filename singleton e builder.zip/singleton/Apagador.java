package singleton;

public class Apagador {
	
	
	private String color;
	
	
	
		
	

}
